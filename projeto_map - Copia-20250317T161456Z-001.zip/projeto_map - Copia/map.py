import pandas as pd
import plotly.express as px
import os

# Caminhos
data_path = 'C:\\Users\\glori\\Documents\\projeto_map\\dados_ficticios.xlsx'
output_folder = 'C:\\Users\\glori\\Documents\\projeto_map\\grafico_output\\'

# Carregar Dataset
try:
    df = pd.read_excel(data_path)
    print("Arquivo carregado com sucesso!")
except Exception as e:
    print(f"Erro ao carregar o arquivo: {e}")
    exit()

# Garantir que os nomes das colunas não tenham espaços extras
df.columns = df.columns.str.strip()

# Criar pasta de saída, se não existir
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Lista de caminhos para os gráficos
grafico_paths = []

# Função para salvar gráficos interativos
def salvar_grafico(fig, nome_arquivo):
    fig_path = os.path.join(output_folder, nome_arquivo)
    fig.write_html(fig_path)
    grafico_paths.append(fig_path)

# 1. **Distribuição da Idade dos Participantes**
fig = px.histogram(df, x='Idade', nbins=15, 
                   title='Distribuição de Idade dos Participantes', 
                   labels={'Idade': 'Idade'})
fig.update_traces(marker_color='skyblue')
salvar_grafico(fig, 'grafico_idade.html')

# 2. **Distribuição de Formação Acadêmica**
formacao_counts = df['Formação'].value_counts().reset_index()
formacao_counts.columns = ['Formação', 'Contagem']
fig = px.bar(formacao_counts, x='Formação', y='Contagem', 
             title='Distribuição de Formação Acadêmica dos Participantes', 
             labels={'Formação': 'Formação Acadêmica', 'Contagem': 'Número de Participantes'})
fig.update_traces(marker_color='lightgreen')
salvar_grafico(fig, 'grafico_formacao.html')

# 3. **Distribuição de Senioridade**
senioridade_counts = df['Senioridade'].value_counts().reset_index()
senioridade_counts.columns = ['Senioridade', 'Contagem']
fig = px.bar(senioridade_counts, x='Senioridade', y='Contagem', 
             title='Distribuição de Senioridade dos Participantes', 
             labels={'Senioridade': 'Nível de Senioridade', 'Contagem': 'Número de Participantes'})
fig.update_traces(marker_color='lightcoral')
salvar_grafico(fig, 'grafico_senioridade.html')

# 4. **Distribuição Geográfica (Estado)**
estado_counts = df['Estado'].value_counts().reset_index()
estado_counts.columns = ['Estado', 'Contagem']
fig = px.bar(estado_counts, x='Estado', y='Contagem', 
             title='Distribuição dos Participantes por Estado', 
             labels={'Estado': 'Estado', 'Contagem': 'Número de Participantes'})
fig.update_traces(marker_color='lightblue')
salvar_grafico(fig, 'grafico_estado.html')

# 5. **Distribuição Geográfica (Cidade)**
cidade_counts = df['Cidade'].value_counts().reset_index()
cidade_counts.columns = ['Cidade', 'Contagem']
fig = px.bar(cidade_counts, x='Cidade', y='Contagem', 
             title='Distribuição dos Participantes por Cidade', 
             labels={'Cidade': 'Cidade', 'Contagem': 'Número de Participantes'})
fig.update_traces(marker_color='orange')
salvar_grafico(fig, 'grafico_cidade.html')

# 6. **Comparação entre Idade e Senioridade**
senioridade_map = {'Júnior': 1, 'Pleno': 2, 'Sênior': 3}
df['Senioridade_num'] = df['Senioridade'].map(senioridade_map)
fig = px.box(df, x='Senioridade_num', y='Idade', 
             title='Comparação entre Idade e Senioridade',
             labels={'Senioridade_num': 'Senioridade', 'Idade': 'Idade'})
fig.update_traces(marker_color='lightpink')
salvar_grafico(fig, 'grafico_idade_senioridade.html')

# 7. **Relação entre Formação e Senioridade**
fig = px.histogram(df, x='Senioridade', color='Formação', 
                   title='Relação entre Formação Acadêmica e Senioridade', 
                   labels={'Senioridade': 'Senioridade', 'Formação': 'Formação Acadêmica'})
salvar_grafico(fig, 'grafico_formacao_senioridade.html')

# 8. **Distribuição de Senioridade por Estado**
df_senioridade_estado = df.groupby(['Estado', 'Senioridade']).size().reset_index(name='Contagem')
fig = px.bar(df_senioridade_estado, x='Estado', y='Contagem', color='Senioridade', 
             title='Distribuição de Senioridade por Estado', 
             labels={'Estado': 'Estado', 'Contagem': 'Número de Participantes'})
salvar_grafico(fig, 'grafico_senioridade_estado.html')

# 9. **Participação por Senioridade por Estado**
fig = px.bar(df, x='Estado', color='Senioridade', 
             title='Participação por Estado e Nível de Senioridade', 
             labels={'Estado': 'Estado', 'Senioridade': 'Nível de Senioridade'})
salvar_grafico(fig, 'grafico_participacao_estado_senioridade.html')

# 10. **Análise de Idade por Formação**
fig = px.box(df, x='Formação', y='Idade', 
             title='Distribuição de Idade por Formação Acadêmica', 
             labels={'Formação': 'Formação Acadêmica', 'Idade': 'Idade'})
salvar_grafico(fig, 'grafico_idade_formacao.html')

# Criar Página HTML com Menu de Gráficos
html_content = '''
<html>
<head>
    <title>Gráficos Interativos - Análise de Participantes</title>
</head>
<body>
    <h1>Gráficos Interativos</h1>
    <ul>
'''

# Adicionar links para os gráficos
for path in grafico_paths:
    nome_arquivo = os.path.basename(path)
    html_content += f'<li><a href="{nome_arquivo}" target="_blank">{nome_arquivo}</a></li>\n'

html_content += '''
    </ul>
</body>
</html>
'''

# Salvar HTML
menu_path = os.path.join(output_folder, 'menu_graficos.html')
with open(menu_path, 'w') as f:
    f.write(html_content)

print(f"Página HTML criada: {menu_path}")
